<!DOCTYPE html>
<html>
<head>
    <title>ePharmacy | Welcome</title>
    <link rel = "stylesheet" type = "text/css" href = "https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
</head>
<body>
    <div class = "container">
        <div class = "row">
            <div class = "col-md-10 offset = md - 1">
                <div class = "row">
                    <div class = "col-md-5 register-left">
                       <h3 style="color: blue;"><br><br><br>ePharmacy Bangladesh</h3>
                        <script>
                            document.write(Date());
                        </script>
                            <h5 style="color: red;">Your account has deactivated! Contact with admin to active your account! Or if you are a new user, (just created your account) then waits for 72 hours. </h5>

                            <!-- logout -->
                        <a href="pharmacyLogin.php" style="color: red;">Login</a>
                   
                    </div> 
                </div>
            </div>
        </div>
    </div>
</body>
</html>