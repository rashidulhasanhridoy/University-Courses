-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2019 at 02:21 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epharmacy`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `sl` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `request` int(11) NOT NULL,
  `joinDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`sl`, `name`, `userName`, `email`, `phoneNumber`, `password`, `request`, `joinDate`) VALUES
(14, 'Rashidul Hasan Hridoy', 'hridoy', 'hridoy@mail.com', '01521000000', '81dc9bdb52d04dc20036dbd8313ed055', 1, '04/07/2019'),
(15, 'Yeasin Sad', 'Sad', 'Sad@mail.com', '01521000000', '81dc9bdb52d04dc20036dbd8313ed055', 0, '04/07/2019'),
(16, 'Smith Mondol', 'Smith', 'Smith@mail.com', '01521000000', '81dc9bdb52d04dc20036dbd8313ed055', 0, '04/07/2019'),
(17, 'Rahim Mia', 'Rahim', 'Rahim@mail.com', '01300998877', '827ccb0eea8a706c4c34a16891f84e7b', 1, '04/08/2019');

-- --------------------------------------------------------

--
-- Table structure for table `deactiveinfo`
--

CREATE TABLE `deactiveinfo` (
  `sl` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `adminName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deactiveinfo`
--

INSERT INTO `deactiveinfo` (`sl`, `type`, `userName`, `reason`, `date`, `adminName`) VALUES
(1, 'customer', 'Shakil', 'reveiw', 'Apr,08,2019 12:58:39 AM', 'hridoy'),
(2, 'Pharmacy', 'Sajeeb', 'vacation', 'Apr,08,2019 12:59:26 AM', 'hridoy'),
(3, 'pharmacy', 'Sajeeb', 'vacation', 'Apr,08,2019 01:00:17 AM', 'hridoy');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderNumber` varchar(255) NOT NULL,
  `pharmacyUserName` varchar(255) DEFAULT NULL,
  `pharmacyName` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `customerUserName` varchar(255) NOT NULL,
  `customerName` varchar(255) NOT NULL,
  `customerPhoneNumber` varchar(255) NOT NULL,
  `customerReveiw` int(1) NOT NULL,
  `pharmacyReveiw` int(1) NOT NULL,
  `productName` varchar(255) DEFAULT NULL,
  `productCompany` varchar(255) DEFAULT NULL,
  `productPrize` int(11) DEFAULT NULL,
  `productQuantity` int(11) NOT NULL,
  `productTotalAmount` int(11) DEFAULT NULL,
  `orderDate` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `submit` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderNumber`, `pharmacyUserName`, `pharmacyName`, `phoneNumber`, `customerUserName`, `customerName`, `customerPhoneNumber`, `customerReveiw`, `pharmacyReveiw`, `productName`, `productCompany`, `productPrize`, `productQuantity`, `productTotalAmount`, `orderDate`, `status`, `submit`) VALUES
('SHAKIL1554667755', 'Sajeeb', 'Sajeeb Pharmacy Ltd., Uttora Sector 7, Dhaka', '01512000000', 'SHAKIL', 'Shakil Ahamed', '01511002233', 4, 5, 'A', 'Z', 5, 2, 10, 'Apr,07,2019 22:09:15 PM', 'received', 4),
('SHAKIL1554667755', 'Sajeeb', 'Sajeeb Pharmacy Ltd., Uttora Sector 7, Dhaka', '01512000000', 'SHAKIL', 'Shakil Ahamed', '01511002233', 4, 5, 'B', 'X', 5, 2, 10, 'Apr,07,2019 22:09:15 PM', 'received', 4),
('SHAKIL1554667755', 'Sajeeb', 'Sajeeb Pharmacy Ltd., Uttora Sector 7, Dhaka', '01512000000', 'SHAKIL', 'Shakil Ahamed', '01511002233', 4, 5, 'C', 'Y', 6, 2, 12, 'Apr,07,2019 22:09:15 PM', 'received', 4),
('SHAKIL1554668017', 'Hafiz', 'Hafiz Pharmacy Ltd., Gulshan 2, Dhaka', '01512000000', 'SHAKIL', 'Shakil Ahamed', '01511002233', 0, 0, 'D', 'K', 10, 2, 20, 'Apr,07,2019 22:13:37 PM', 'pending', 1),
('SHAKIL1554668017', 'Hafiz', 'Hafiz Pharmacy Ltd., Gulshan 2, Dhaka', '01512000000', 'SHAKIL', 'Shakil Ahamed', '01511002233', 0, 0, 'E', 'G', 8, 3, 24, 'Apr,07,2019 22:13:37 PM', 'pending', 1),
('SHAKIL1554668158', 'Sajeeb', 'Sajeeb Pharmacy Ltd., Uttora Sector 7, Dhaka', '01512000000', 'SHAKIL', 'Shakil Ahamed', '01511002233', 5, 3, 'A', 'Z', 5, 1, 5, 'Apr,07,2019 22:15:58 PM', 'received', 4),
('SHAKIL1554668158', 'Sajeeb', 'Sajeeb Pharmacy Ltd., Uttora Sector 7, Dhaka', '01512000000', 'SHAKIL', 'Shakil Ahamed', '01511002233', 5, 3, 'B', 'X', 5, 1, 5, 'Apr,07,2019 22:15:58 PM', 'received', 4),
('SHAKIL1554668418', 'Sajeeb', 'Sajeeb Pharmacy Ltd., Uttora Sector 7, Dhaka', '01512000000', 'SHAKIL', 'Shakil Ahamed', '01511002233', 5, 4, 'B', 'X', 5, 3, 15, 'Apr,07,2019 22:20:18 PM', 'received', 4),
('SHAKIL1554668418', 'Sajeeb', 'Sajeeb Pharmacy Ltd., Uttora Sector 7, Dhaka', '01512000000', 'SHAKIL', 'Shakil Ahamed', '01511002233', 5, 4, 'C', 'Y', 6, 6, 36, 'Apr,07,2019 22:20:18 PM', 'received', 4);

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

CREATE TABLE `pharmacy` (
  `sl` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `pharmacyName` varchar(255) NOT NULL,
  `drugLicenseNumber` varchar(255) NOT NULL,
  `NIDNumber` int(11) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `joinDate` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reveiw` decimal(10,1) NOT NULL,
  `request` int(11) NOT NULL,
  `sell` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pharmacy`
--

INSERT INTO `pharmacy` (`sl`, `name`, `gender`, `pharmacyName`, `drugLicenseNumber`, `NIDNumber`, `userName`, `email`, `phoneNumber`, `joinDate`, `password`, `reveiw`, `request`, `sell`) VALUES
(0, 'Faiza Kaha', 'Female', 'Faiza Ltd, Munsigonj', '123456789', 1234567879, 'Faiza', 'Faiza@mail.com', '01411223322', '04/07/2019', '827ccb0eea8a706c4c34a16891f84e7b', '0.0', 1, 'on'),
(0, 'Imran Hafiz', 'Male', 'Hafiz Pharmacy Ltd., Gulshan 2, Dhaka', '123456789', 123456789, 'Hafiz', 'Hafiz@mail.com', '01512000000', '04/07/2019', '81dc9bdb52d04dc20036dbd8313ed055', '0.0', 1, 'on'),
(0, 'Maisha Ahamed', 'Female', 'Maisha Pharmacy Ltd., Bonani 2, Dhaka', '123456789', 123456789, 'Maisha', 'Maisha@mail.com', '01512000000', '04/07/2019', '81dc9bdb52d04dc20036dbd8313ed055', '0.0', 1, 'on'),
(0, 'Monisha Ahamed', 'Female', 'Monisha Pharmacy Ltd, Dhanmondi 32, Dhaka', '123456789', 123456789, 'Monisha', 'Monisha@mail.com', '01512000000', '04/07/2019', '81dc9bdb52d04dc20036dbd8313ed055', '0.0', 1, 'on'),
(0, 'Sajeeb Khan', 'Male', 'Sajeeb Pharmacy Ltd., Uttora Sector 7, Dhaka', '123456789', 123456789, 'Sajeeb', 'Sajeeb@mail.com', '01512000000', '04/07/2019', 'e10adc3949ba59abbe56e057f20f883e', '0.0', 1, 'on');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `sl` int(11) NOT NULL,
  `productName` varchar(255) DEFAULT NULL,
  `productCompany` varchar(255) DEFAULT NULL,
  `productQuantity` int(11) DEFAULT NULL,
  `productPrize` int(11) DEFAULT NULL,
  `addDate` varchar(255) NOT NULL,
  `userName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`sl`, `productName`, `productCompany`, `productQuantity`, `productPrize`, `addDate`, `userName`) VALUES
(21, 'A', 'Z', 10, 5, 'Apr,07,2019 10:07:43 PM', 'Sajeeb'),
(22, 'B', 'X', 15, 5, 'Apr,07,2019 10:08:02 PM', 'Sajeeb'),
(23, 'C', 'Y', 10, 6, 'Apr,07,2019 10:08:26 PM', 'Sajeeb'),
(24, 'D', 'K', 10, 10, 'Apr,07,2019 10:12:13 PM', 'hafiz'),
(25, 'E', 'G', 10, 8, 'Apr,07,2019 10:12:34 PM', 'hafiz'),
(26, 'F', 'V', 5, 10, 'Apr,07,2019 10:37:19 PM', 'Sajeeb');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `joinDate` varchar(255) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reveiw` decimal(2,1) NOT NULL,
  `buy` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `joinDate`, `userName`, `name`, `gender`, `email`, `phoneNumber`, `password`, `reveiw`, `buy`) VALUES
(0, '04/07/2019', 'hasib', 'Hasib Khan', 'Male', 'hasib@mail.com', '01521000000', '81dc9bdb52d04dc20036dbd8313ed055', '0.0', 'on'),
(0, '04/07/2019', 'Shakib', 'Shakib Hasan', 'Male', 'Shakib@mail.com', '01511223333', '827ccb0eea8a706c4c34a16891f84e7b', '0.0', 'on'),
(0, '04/07/2019', 'Shakil', 'Shakil Khan', 'Male', 'Shakil@mail.com', '01511002233', '827ccb0eea8a706c4c34a16891f84e7b', '0.0', 'on'),
(0, '04/07/2019', 'Shima', 'Shima Ahammed', 'Female', 'Shima@mail.com', '01521000000', '81dc9bdb52d04dc20036dbd8313ed055', '0.0', 'on');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `deactiveinfo`
--
ALTER TABLE `deactiveinfo`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD KEY `PharmacyUserName` (`pharmacyUserName`);

--
-- Indexes for table `pharmacy`
--
ALTER TABLE `pharmacy`
  ADD PRIMARY KEY (`userName`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`sl`),
  ADD KEY `userName` (`userName`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `deactiveinfo`
--
ALTER TABLE `deactiveinfo`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`PharmacyUserName`) REFERENCES `products` (`userName`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`userName`) REFERENCES `pharmacy` (`userName`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
