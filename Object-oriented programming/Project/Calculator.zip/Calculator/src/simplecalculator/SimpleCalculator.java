package simplecalculator;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;

public class SimpleCalculator {

	private JFrame frame;
	private JTextField textFieldNumber1;
	private JTextField textFieldNumber2;
	private JTextField textFieldResult;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SimpleCalculator window = new SimpleCalculator();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SimpleCalculator() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(127, 255, 212));
		frame.getContentPane().setForeground(new Color(175, 238, 238));
		frame.setBounds(100, 100, 450, 330);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textFieldNumber1 = new JTextField();
		textFieldNumber1.setText("00");
		textFieldNumber1.setFont(new Font("Tahoma", Font.BOLD, 16));
		textFieldNumber1.setBounds(10, 11, 198, 49);
		frame.getContentPane().add(textFieldNumber1);
		textFieldNumber1.setColumns(10);
		
		textFieldNumber2 = new JTextField();
		textFieldNumber2.setText("00");
		textFieldNumber2.setFont(new Font("Tahoma", Font.BOLD, 16));
		textFieldNumber2.setColumns(10);
		textFieldNumber2.setBounds(226, 11, 198, 49);
		frame.getContentPane().add(textFieldNumber2);
		
		JButton btnNewButton = new JButton("ADDITION");
		btnNewButton.setBackground(new Color(255, 255, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					int num1 =  Integer.parseInt(textFieldNumber1.getText());
					int num2 =  Integer.parseInt(textFieldNumber2.getText());
					int result = num1 + num2;
					textFieldResult.setText(Integer.toString(result));
					
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Error! Try Again with correct input.");
					
				}
			}
		});
		btnNewButton.setForeground(new Color(0, 0, 255));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setBounds(10, 71, 198, 39);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnSubtraction = new JButton("SUBTRACTION");
		btnSubtraction.setBackground(new Color(255, 255, 0));
		btnSubtraction.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					int num1 =  Integer.parseInt(textFieldNumber1.getText());
					int num2 =  Integer.parseInt(textFieldNumber2.getText());
					int result = num1 - num2;
					textFieldResult.setText(Integer.toString(result));
					
				}
				catch(Exception e2) {
					JOptionPane.showMessageDialog(null, "Error! Try Again with correct input.");
					
				}
			}
		});
		btnSubtraction.setForeground(new Color(0, 0, 255));
		btnSubtraction.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnSubtraction.setBounds(226, 71, 198, 39);
		frame.getContentPane().add(btnSubtraction);
		
		JButton btnMultiplication = new JButton("MULTIPLICATION");
		btnMultiplication.setBackground(new Color(255, 255, 0));
		btnMultiplication.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					int num1 =  Integer.parseInt(textFieldNumber1.getText());
					int num2 =  Integer.parseInt(textFieldNumber2.getText());
					int result = num1 * num2;
					textFieldResult.setText(Integer.toString(result));
					
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Error! Try Again with correct input.");
					
				}
			}
		});
		btnMultiplication.setForeground(new Color(0, 0, 255));
		btnMultiplication.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnMultiplication.setBounds(10, 121, 198, 39);
		frame.getContentPane().add(btnMultiplication);
		
		JButton btnDivision = new JButton("DIVISION");
		btnDivision.setBackground(new Color(255, 255, 0));
		btnDivision.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					int num1 =  Integer.parseInt(textFieldNumber1.getText());
					int num2 =  Integer.parseInt(textFieldNumber2.getText());
					if(num2 == 0) {
						JOptionPane.showMessageDialog(null, "Error! Try Again with correct input.");
						
					}
					
					else {
						
						int result = num1 / num2;
						textFieldResult.setText(Integer.toString(result));
						
					}
					
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Error! Try Again with correct input.");
					
				}
			}
		});
		btnDivision.setForeground(new Color(0, 0, 255));
		btnDivision.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnDivision.setBounds(226, 121, 198, 39);
		frame.getContentPane().add(btnDivision);
		
		JButton btnReset = new JButton("RESET");
		btnReset.setBackground(new Color(50, 205, 50));
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				textFieldNumber1.setText("00");
				textFieldNumber2.setText("00");
				textFieldResult.setText("");
			}
		});
		btnReset.setForeground(new Color(255, 255, 255));
		btnReset.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnReset.setBounds(10, 231, 198, 39);
		frame.getContentPane().add(btnReset);
		
		JButton btnExit = new JButton("EXIT");
		btnExit.setBackground(new Color(220, 20, 60));
		btnExit.setForeground(new Color(255, 255, 255));
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		btnExit.setBounds(226, 231, 198, 39);
		frame.getContentPane().add(btnExit);
		
		textFieldResult = new JTextField();
		textFieldResult.setFont(new Font("Tahoma", Font.BOLD, 16));
		textFieldResult.setColumns(10);
		textFieldResult.setBounds(10, 171, 414, 49);
		frame.getContentPane().add(textFieldResult);
	}
}
