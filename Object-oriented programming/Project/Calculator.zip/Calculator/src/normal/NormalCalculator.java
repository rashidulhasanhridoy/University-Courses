package normal;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;

public class NormalCalculator {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NormalCalculator window = new NormalCalculator();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public NormalCalculator() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 350, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel.setBounds(10, 17, 314, 73);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("OFF");
		btnNewButton.setBackground(new Color(135, 206, 235));
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(10, 107, 71, 45);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnAc = new JButton("AC");
		btnAc.setBackground(new Color(135, 206, 235));
		btnAc.setForeground(new Color(0, 0, 0));
		btnAc.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnAc.setBounds(91, 107, 71, 45);
		frame.getContentPane().add(btnAc);
		
		JButton button_1 = new JButton("%");
		button_1.setBackground(new Color(135, 206, 235));
		button_1.setForeground(new Color(0, 0, 0));
		button_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_1.setBounds(172, 107, 71, 45);
		frame.getContentPane().add(button_1);
		
		JButton button_2 = new JButton("/");
		button_2.setBackground(new Color(135, 206, 235));
		button_2.setForeground(new Color(0, 0, 0));
		button_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_2.setBounds(253, 107, 71, 45);
		frame.getContentPane().add(button_2);
		
		JButton button_3 = new JButton("7");
		button_3.setBackground(new Color(220, 220, 220));
		button_3.setForeground(new Color(0, 0, 0));
		button_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_3.setBounds(10, 168, 71, 45);
		frame.getContentPane().add(button_3);
		
		JButton button_4 = new JButton("8");
		button_4.setBackground(new Color(220, 220, 220));
		button_4.setForeground(new Color(0, 0, 0));
		button_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_4.setBounds(90, 169, 71, 45);
		frame.getContentPane().add(button_4);
		
		JButton button_5 = new JButton("9");
		button_5.setBackground(new Color(220, 220, 220));
		button_5.setForeground(new Color(0, 0, 0));
		button_5.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_5.setBounds(173, 168, 71, 45);
		frame.getContentPane().add(button_5);
		
		JButton btnX = new JButton("X");
		btnX.setBackground(new Color(135, 206, 235));
		btnX.setForeground(new Color(0, 0, 0));
		btnX.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnX.setBounds(253, 168, 71, 45);
		frame.getContentPane().add(btnX);
		
		JButton button_7 = new JButton("4");
		button_7.setBackground(new Color(220, 220, 220));
		button_7.setForeground(new Color(0, 0, 0));
		button_7.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_7.setBounds(8, 227, 71, 45);
		frame.getContentPane().add(button_7);
		
		JButton button_8 = new JButton("5");
		button_8.setBackground(new Color(220, 220, 220));
		button_8.setForeground(new Color(0, 0, 0));
		button_8.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_8.setBounds(90, 227, 71, 45);
		frame.getContentPane().add(button_8);
		
		JButton button_9 = new JButton("6");
		button_9.setBackground(new Color(220, 220, 220));
		button_9.setForeground(new Color(0, 0, 0));
		button_9.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_9.setBounds(173, 226, 71, 45);
		frame.getContentPane().add(button_9);
		
		JButton button_10 = new JButton("-");
		button_10.setBackground(new Color(135, 206, 235));
		button_10.setForeground(new Color(0, 0, 0));
		button_10.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_10.setBounds(254, 224, 71, 45);
		frame.getContentPane().add(button_10);
		
		JButton button_11 = new JButton("1");
		button_11.setBackground(new Color(220, 220, 220));
		button_11.setForeground(new Color(0, 0, 0));
		button_11.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_11.setBounds(10, 286, 71, 45);
		frame.getContentPane().add(button_11);
		
		JButton button_12 = new JButton("2");
		button_12.setBackground(new Color(220, 220, 220));
		button_12.setForeground(new Color(0, 0, 0));
		button_12.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_12.setBounds(92, 285, 71, 45);
		frame.getContentPane().add(button_12);
		
		JButton button_13 = new JButton("3");
		button_13.setBackground(new Color(220, 220, 220));
		button_13.setForeground(new Color(0, 0, 0));
		button_13.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_13.setBounds(173, 284, 71, 45);
		frame.getContentPane().add(button_13);
		
		JButton button_14 = new JButton("+");
		button_14.setBackground(new Color(135, 206, 235));
		button_14.setForeground(new Color(0, 0, 0));
		button_14.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_14.setBounds(255, 283, 71, 45);
		frame.getContentPane().add(button_14);
		
		JButton button_15 = new JButton("00");
		button_15.setBackground(new Color(220, 220, 220));
		button_15.setForeground(new Color(0, 0, 0));
		button_15.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button_15.setBounds(10, 347, 71, 45);
		frame.getContentPane().add(button_15);
		
		JButton button_16 = new JButton("0");
		button_16.setBackground(new Color(220, 220, 220));
		button_16.setForeground(new Color(0, 0, 0));
		button_16.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_16.setBounds(92, 347, 71, 45);
		frame.getContentPane().add(button_16);
		
		JButton button_17 = new JButton(".");
		button_17.setBackground(new Color(220, 220, 220));
		button_17.setForeground(new Color(0, 0, 0));
		button_17.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_17.setBounds(173, 346, 71, 45);
		frame.getContentPane().add(button_17);
		
		JButton button_18 = new JButton("=");
		button_18.setBackground(new Color(135, 206, 235));
		button_18.setForeground(new Color(0, 0, 0));
		button_18.setFont(new Font("Tahoma", Font.BOLD, 18));
		button_18.setBounds(255, 345, 71, 45);
		frame.getContentPane().add(button_18);
	}
}
