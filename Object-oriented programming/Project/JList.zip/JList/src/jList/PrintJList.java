package jList;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;

public class PrintJList extends JFrame {
	
	public PrintJList() {
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setLayout(new FlowLayout());
		ArrayList<String> items = new ArrayList<String>();
		for(int i = 0; i < 10; i++) {
			
			items.add("Item " + i);
		}
		
		final JList<String> list = new JList(items.toArray());
		getContentPane().add(list);
		
		JButton btn = new JButton("Print");
		getContentPane().add(btn);
		
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e1) {
				// TODO Auto-generated method stub
				
				int[] indices = list.getSelectedIndices();
				for(int i = 0; i < indices.length; i++) {
					
					System.out.println("Item " +  indices[i]);
				}
				
			}
		});
		
		setSize(300, 300);
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		new PrintJList().setVisible(true);

	}

}
